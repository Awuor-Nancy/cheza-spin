<footer class="mm-footer">
    <div class="container-fluid">
        <div class="row">
            <div class="col-lg-6">
                <ul class="list-inline mb-0">
                    <li class="list-inline-item"><a href="#">Privacy Policy</a></li>
                    <li class="list-inline-item"><a href="#">Terms of Use</a></li>
                </ul>
            </div>
            <div class="col-lg-6 text-right">
                <span class="mr-1">
                    Copyright
                    <?php date('Y')?>© <a href="#" class="">MightyWeb</a>
                    All Rights Reserved.
                </span>
            </div>
        </div>
    </div>
</footer>
<script src="../assets/js/backend-bundle.min.js"></script>
    
    <!-- Chart Custom JavaScript -->
    <script src="../assets/js/customizer.js"></script>
    
    
    <!-- slider JavaScript -->
    <!-- <script src="../assets/js/slider.js"></script> -->
    
    <!-- Emoji picker -->
    <!-- <script src="../assets/vendor/emoji-picker-element/index.js" type="module"></script> -->
    
    <!-- app JavaScript -->
    <script src="../assets/js/app.js"></script>
    <script src="../assets/js/custom.js"></script>
