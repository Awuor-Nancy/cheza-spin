<footer class="footer">
	<div class="container-fluid">
		<div class="row">
			<div class="col-md-12">
				<?= date('Y') ?> &copy; Simple theme by <a href="#">Coderthemes</a>
			</div>
		</div>
	</div>
</footer>
